"""OpenGL polygon application package."""
