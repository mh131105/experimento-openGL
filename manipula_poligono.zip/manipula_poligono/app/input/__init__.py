"""Keyboard input handling."""
